﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        private enum ExitCode : int
        {
            Success = 0,
            IncorrectArguments = 1
        }

        private static string functionality;
        private static string fileName;

        public static int Main(string[] args)
        {

            if (args.Length != 2)
            {
                Console.WriteLine("Please provide arguments <functionality to perform> <filename>");
                return (int)ExitCode.IncorrectArguments;
            }

            functionality = args[0];
            fileName = args[1];

            switch(functionality)
            {
                case "-v": case "--v": case "/v": case "--version":
                    Console.WriteLine(string.Format("File Version is: {0}", GetFileVersion(fileName)));
                    return (int)ExitCode.Success;
                    

                case "-s": case "--s": case "/s": case "--size":
                    Console.WriteLine(string.Format("File Size is: {0} bytes", GetFileSize(fileName)));
                    return (int)ExitCode.Success;

                default:
                    Console.WriteLine("Functionality must be '-v, --v, /v, --version' or '-s, --s, /s, --size' - incorrect argument passed");
                    return (int)ExitCode.IncorrectArguments;


            }
        }

        private static string GetFileVersion(string fileName)
        {
            FileDetails fileDetails = new FileDetails();
            return fileDetails.Version(fileName);
        }

        private static int GetFileSize(string fileName)
        {
            FileDetails fileDetails = new FileDetails();
            return (fileDetails.Size(fileName));
        }
    }
}
